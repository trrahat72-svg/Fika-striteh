import React, { useEffect, useRef, useCallback } from 'react';
import { spriteAudio } from '../utils/audio';

interface ProductSpotlightRevealProps {
  baseImage: string;
  revealImage: string;
  alt?: string;
  className?: string;
  spotlightRadius?: number;
}

export const ProductSpotlightReveal: React.FC<ProductSpotlightRevealProps> = ({
  baseImage,
  revealImage,
  alt = 'Sprite Product',
  className = '',
  spotlightRadius = 220,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const targetPos = useRef<{ x: number; y: number; active: boolean }>({
    x: -9999,
    y: -9999,
    active: false,
  });
  const currentPos = useRef<{ x: number; y: number; opacity: number }>({
    x: -9999,
    y: -9999,
    opacity: 0,
  });
  const revealDivRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);
  const fadeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastSoundTime = useRef<number>(0);

  // Sound feedback on reveal interaction
  const triggerAudioFizz = useCallback(() => {
    const now = Date.now();
    if (now - lastSoundTime.current > 120) {
      spriteAudio.playFizzBubble();
      lastSoundTime.current = now;
    }
  }, []);

  // Continuous smooth interpolation (LERP) loop for butter-smooth 60fps tracking
  useEffect(() => {
    const updateMask = () => {
      const target = targetPos.current;
      const current = currentPos.current;

      // Lerp position & opacity
      if (target.active) {
        if (current.x === -9999 || current.opacity < 0.05) {
          // Instant snap on fresh touch/hover to prevent visual streaking
          current.x = target.x;
          current.y = target.y;
        } else {
          current.x += (target.x - current.x) * 0.2;
          current.y += (target.y - current.y) * 0.2;
        }
        current.opacity += (1 - current.opacity) * 0.15;
      } else {
        current.opacity += (0 - current.opacity) * 0.06;
      }

      if (revealDivRef.current) {
        if (current.opacity > 0.005) {
          const r = spotlightRadius;
          const mask = `radial-gradient(circle ${r}px at ${current.x}px ${current.y}px, rgba(0,0,0,1) 0%, rgba(0,0,0,0.9) 30%, rgba(0,0,0,0.6) 55%, rgba(0,0,0,0.3) 75%, rgba(0,0,0,0.08) 90%, rgba(0,0,0,0) 100%)`;
          revealDivRef.current.style.maskImage = mask;
          revealDivRef.current.style.webkitMaskImage = mask;
          revealDivRef.current.style.opacity = `${current.opacity}`;
          revealDivRef.current.style.visibility = 'visible';
        } else {
          revealDivRef.current.style.opacity = '0';
          revealDivRef.current.style.visibility = 'hidden';
        }
      }

      rafRef.current = requestAnimationFrame(updateMask);
    };

    rafRef.current = requestAnimationFrame(updateMask);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [spotlightRadius]);

  const updateCoordinates = useCallback((clientX: number, clientY: number, isInitialTouch = false) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const width = containerRef.current.offsetWidth || rect.width;
    const height = containerRef.current.offsetHeight || rect.height;

    const scaleX = rect.width > 0 ? width / rect.width : 1;
    const scaleY = rect.height > 0 ? height / rect.height : 1;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    if (isInitialTouch) {
      currentPos.current.x = x;
      currentPos.current.y = y;
    }

    targetPos.current = {
      x,
      y,
      active: true,
    };

    triggerAudioFizz();
  }, [triggerAudioFizz]);

  // Pointer Events (Unified for Touch, Stylus, and Mouse)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (fadeTimeoutRef.current) {
      clearTimeout(fadeTimeoutRef.current);
      fadeTimeoutRef.current = null;
    }
    // Capture pointer so moving outside the element while dragging still tracks smoothly
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
    updateCoordinates(e.clientX, e.clientY, true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') {
      if (targetPos.current.active) {
        updateCoordinates(e.clientX, e.clientY, false);
      }
    } else {
      updateCoordinates(e.clientX, e.clientY, false);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
    if (e.pointerType === 'touch') {
      fadeTimeoutRef.current = setTimeout(() => {
        targetPos.current.active = false;
      }, 1000);
    } else {
      targetPos.current.active = false;
    }
  };

  const handlePointerCancel = () => {
    targetPos.current.active = false;
  };

  const handlePointerLeave = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'touch') {
      targetPos.current.active = false;
    }
  };

  // Direct Touch Events (iOS Safari & Android fallback)
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (fadeTimeoutRef.current) {
      clearTimeout(fadeTimeoutRef.current);
      fadeTimeoutRef.current = null;
    }
    if (e.touches.length > 0) {
      const touch = e.touches[0];
      updateCoordinates(touch.clientX, touch.clientY, true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      const touch = e.touches[0];
      updateCoordinates(touch.clientX, touch.clientY, false);
    }
  };

  const handleTouchEnd = () => {
    fadeTimeoutRef.current = setTimeout(() => {
      targetPos.current.active = false;
    }, 1000);
  };

  return (
    <div
      ref={containerRef}
      id="product-spotlight-container"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onPointerLeave={handlePointerLeave}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      className={`relative w-full h-full select-none cursor-crosshair pointer-events-auto touch-none ${className}`}
      style={{ touchAction: 'none', WebkitTapHighlightColor: 'transparent' }}
    >
      {/* 1. BASE PRODUCT IMAGE */}
      <img
        src={baseImage}
        alt={alt}
        className="absolute inset-0 w-full h-full object-contain filter drop-shadow-[0_25px_40px_rgba(0,0,0,0.55)] pointer-events-none z-10"
        crossOrigin="anonymous"
        loading="eager"
        draggable={false}
      />

      {/* 2. REVEAL PRODUCT IMAGE (Masked with smooth spotlight, sized 20px smaller) */}
      <div
        ref={revealDivRef}
        id="product-spotlight-reveal-layer"
        className="absolute inset-0 w-full h-full pointer-events-none z-20 transition-none will-change-[mask-image,opacity] flex items-center justify-center p-[10px]"
        style={{
          opacity: 0,
          visibility: 'hidden',
          WebkitMaskRepeat: 'no-repeat',
          maskRepeat: 'no-repeat',
        }}
      >
        <img
          src={revealImage}
          alt={`${alt} Alternate Reveal`}
          className="w-full h-full object-contain pointer-events-none"
          crossOrigin="anonymous"
          loading="eager"
          draggable={false}
        />
      </div>
    </div>
  );
};
