import React from 'react';
import { Instagram, Facebook } from 'lucide-react';
import { motion } from 'motion/react';

interface SocialLinksProps {
  revealTrigger?: number;
}

export const SocialLinks: React.FC<SocialLinksProps> = ({ revealTrigger = 0 }) => {
  const socialIcons = [
    {
      name: 'Instagram',
      href: 'https://instagram.com',
      icon: <Instagram className="w-3.5 h-3.5" />,
    },
    {
      name: 'TikTok',
      href: 'https://tiktok.com',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298 0 .592.046.87.136V9.4a6.33 6.33 0 0 0-.87-.06A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 10.74 4.54 6.28 6.28 0 0 0 1.94-4.57V8.58a8.28 8.28 0 0 0 4.84 1.56V6.69z" />
        </svg>
      ),
    },
    {
      name: 'Facebook',
      href: 'https://facebook.com',
      icon: <Facebook className="w-3.5 h-3.5" />,
    },
  ];

  return (
    <div className="absolute left-[48px] bottom-[48px] z-20 flex flex-col gap-2.5">
      {/* "Follow Sprite" Label Slide-in */}
      <motion.span
        key={`social-label-${revealTrigger}`}
        initial={{ x: -25, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{
          duration: 0.9,
          delay: 0.85,
          ease: [0.19, 1, 0.22, 1],
        }}
        className="text-white/80 font-montserrat text-[13px] font-medium tracking-wide"
      >
        Follow Sprite
      </motion.span>

      {/* Staggered Pop-in Social Icons */}
      <div className="flex items-center gap-2">
        {socialIcons.map((social, idx) => (
          <motion.a
            key={`${social.name}-${revealTrigger}`}
            href={social.href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Follow Sprite on ${social.name}`}
            initial={{ scale: 0, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{
              duration: 0.7,
              delay: 0.95 + idx * 0.1,
              ease: [0.34, 1.56, 0.64, 1], // Playful spring pop
            }}
            className="w-7 h-7 rounded-full border border-white/30 bg-black/20 backdrop-blur-sm flex items-center justify-center text-white/90 hover:text-white hover:border-white/70 hover:bg-white/20 active:scale-90 transition-all duration-200"
          >
            {social.icon}
          </motion.a>
        ))}
      </div>
    </div>
  );
};
