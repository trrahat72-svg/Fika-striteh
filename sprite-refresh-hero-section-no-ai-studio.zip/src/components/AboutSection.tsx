import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

const ABOUT_BG_IMAGE = 'https://res.cloudinary.com/hm4hiju8/image/upload/v1787807893/629618799_1787807879317356.jpg';

interface AnimatedLineProps {
  children: React.ReactNode;
  progress: any;
  range: [number, number];
  className?: string;
}

const ScrollHighlightLine: React.FC<AnimatedLineProps> = ({
  children,
  progress,
  range,
  className = '',
}) => {
  const opacity = useTransform(progress, [range[0] - 0.05, range[0], range[1], range[1] + 0.05], [0.2, 0.25, 1, 1]);
  const scale = useTransform(progress, [range[0], range[1]], [0.97, 1]);
  const y = useTransform(progress, [range[0], range[1]], [12, 0]);
  const textShadow = useTransform(
    progress,
    [range[0], range[1]],
    [
      '0px 2px 8px rgba(0, 20, 45, 0.2)',
      '0px 4px 18px rgba(0, 35, 70, 0.55), 0px 12px 30px rgba(0, 20, 45, 0.35)',
    ]
  );

  return (
    <motion.h2
      style={{
        opacity,
        scale,
        y,
        textShadow,
      }}
      className={`w-full font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] transition-colors duration-200 ${className}`}
    >
      {children}
    </motion.h2>
  );
};

export const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  // Parallax scroll scrub linked strictly to normalized scroll progress
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start 85%', 'end 15%'],
  });

  // Layered parallax scroll offsets
  const bgY = useTransform(scrollYProgress, [0, 1], [-70, 70]);
  const textGroupY = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const stickerScrollY = useTransform(scrollYProgress, [0, 1], [20, -20]);

  // Dynamic Scroll Highlighting transforms for each line
  // Line 1: 0.08 -> 0.26
  // Line 2: 0.24 -> 0.42
  // Line 3 (FIRE UP badge): 0.40 -> 0.58
  // Line 4: 0.56 -> 0.74
  // Line 5: 0.72 -> 0.90
  const badgeOpacity = useTransform(scrollYProgress, [0.35, 0.40, 0.56, 0.60], [0.22, 0.28, 1, 1]);
  const badgeScale = useTransform(scrollYProgress, [0.40, 0.56], [0.88, 1]);
  const badgeRotate = useTransform(scrollYProgress, [0.40, 0.56], [-6, -2.5]);
  const badgeShadow = useTransform(
    scrollYProgress,
    [0.40, 0.56],
    [
      '0px 4px 12px rgba(0, 20, 45, 0.2)',
      '0px 18px 40px rgba(0, 30, 60, 0.5), 0px 4px 12px rgba(0, 0, 0, 0.28), inset 0px 2px 4px rgba(255, 255, 255, 0.85)',
    ]
  );

  // Depth-of-field blurred bokeh bubbles parallax scrub
  const bubbleForegroundY = useTransform(scrollYProgress, [0, 1], [120, -120]);
  const bubbleMidgroundY = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const bubbleBackgroundY = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative w-full aspect-[9/16] md:aspect-[4/3] md:min-h-[760px] bg-[#6db2ea] text-white flex flex-col items-center justify-center select-none overflow-hidden"
    >
      {/* 
        ========================================================================
        1. ATMOSPHERIC SKY & CLOUDS BACKGROUND WITH SCROLL PARALLAX
        ========================================================================
      */}
      <motion.div
        style={{ y: bgY }}
        className="absolute -inset-16 w-[calc(100%+128px)] h-[calc(100%+128px)] pointer-events-none z-0 overflow-hidden"
      >
        <img
          src={ABOUT_BG_IMAGE}
          alt="Atmospheric Clouds and Sky"
          className="w-full h-full object-cover object-center"
          crossOrigin="anonymous"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-sky-400/10 via-transparent to-[#559fda]/25 pointer-events-none" />
      </motion.div>

      {/* 
        ========================================================================
        2. BLURRED BUBBLE PARTICLES (TRANSPARENT, SOFT EDGES, NO RECTANGULAR BOXES)
        ========================================================================
      */}
      
      {/* Layer A: Heavy Foreground Blurred Bubble (Camera Close-up Bokeh) */}
      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute top-[8%] left-[4%] sm:left-[8%] pointer-events-none z-10"
      >
        <div
          className="w-32 h-32 sm:w-44 sm:h-44 md:w-56 md:h-56 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
          }}
        >
          <div className="absolute top-4 left-6 w-10 h-5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-6 right-8 w-5 h-5 rounded-full bg-white/40" />
        </div>
      </motion.div>

      {/* Layer B: Midground Soft-Blurred Bubble (Top Right) */}
      <motion.div
        style={{ y: bubbleMidgroundY }}
        className="absolute top-[16%] right-[5%] sm:right-[10%] pointer-events-none z-10"
      >
        <div
          className="w-24 h-24 sm:w-36 sm:h-36 md:w-44 md:h-44 rounded-full bg-white/22 border border-white/35 shadow-[inset_0_4px_14px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(4px)',
            WebkitBackdropFilter: 'blur(4px)',
          }}
        >
          <div className="absolute top-3 left-4 w-8 h-4 rounded-full bg-white/75 -rotate-45" />
          <div className="absolute bottom-3 right-5 w-4 h-4 rounded-full bg-white/35" />
        </div>
      </motion.div>

      {/* Layer C: Deep Background Small Blurred Bubble (Bottom Left) */}
      <motion.div
        style={{ y: bubbleBackgroundY }}
        className="absolute bottom-[14%] left-[8%] sm:left-[14%] pointer-events-none z-10"
      >
        <div
          className="w-16 h-16 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-full bg-white/25 border border-white/40 shadow-[inset_0_2px_10px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(3px)',
          }}
        >
          <div className="absolute top-2 left-3 w-5 h-2.5 rounded-full bg-white/80 -rotate-45" />
        </div>
      </motion.div>

      {/* Layer D: Heavy Foreground Blurred Bubble (Bottom Right) */}
      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute bottom-[8%] right-[4%] sm:right-[8%] pointer-events-none z-10"
      >
        <div
          className="w-28 h-28 sm:w-40 sm:h-40 md:w-52 md:h-52 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(7px)',
          }}
        >
          <div className="absolute top-4 left-5 w-9 h-4.5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-5 right-6 w-4 h-4 rounded-full bg-white/30" />
        </div>
      </motion.div>

      {/* Layer E: Ambient Micro Bubble (Center-Left) */}
      <motion.div
        style={{ y: bubbleMidgroundY }}
        className="absolute top-[48%] left-[16%] pointer-events-none z-10 hidden sm:block"
      >
        <div
          className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white/25 border border-white/40 shadow-[inset_0_2px_6px_rgba(255,255,255,0.7)] relative overflow-hidden"
          style={{
            filter: 'blur(2px)',
          }}
        >
          <div className="absolute top-1.5 left-2 w-3 h-1.5 rounded-full bg-white/80 -rotate-45" />
        </div>
      </motion.div>

      {/* 
        ========================================================================
        3. TYPOGRAPHY WITH DYNAMIC SCROLL HIGHLIGHTING (REVEAL ON SCROLL)
        ========================================================================
      */}
      <motion.div
        style={{ y: textGroupY }}
        className="relative z-30 w-full max-w-5xl px-4 sm:px-6 lg:px-8 py-8 sm:py-16 md:py-0 landscape:max-md:-translate-y-[15px] flex flex-col items-center justify-center text-center tracking-normal"
      >
        {/* LINE 1: STIR UP YOUR */}
        <ScrollHighlightLine
          progress={scrollYProgress}
          range={[0.08, 0.28]}
          className="text-white"
        >
          STIR UP YOUR
        </ScrollHighlightLine>

        {/* LINE 2: FEARLESS PAST AND */}
        <ScrollHighlightLine
          progress={scrollYProgress}
          range={[0.24, 0.44]}
          className="text-white mt-1 sm:mt-2"
        >
          FEARLESS PAST AND
        </ScrollHighlightLine>

        {/* LINE 3: CRISP ANCHORED HIGHLIGHTER STICKER [FIRE UP] */}
        <motion.div
          style={{ y: stickerScrollY }}
          className="my-2.5 sm:my-5 md:my-7 z-30"
        >
          <motion.div
            style={{
              opacity: badgeOpacity,
              scale: badgeScale,
              rotate: badgeRotate,
              boxShadow: badgeShadow,
            }}
            className="relative px-6 sm:px-10 md:px-14 py-2 sm:py-3.5 md:py-4 bg-[#b5f500] text-[#051017] font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-wider rounded-sm"
          >
            {/* Top gloss tape sheen */}
            <div className="absolute top-0 left-0 right-0 h-[36%] bg-gradient-to-b from-white/40 to-transparent pointer-events-none rounded-t-sm" />
            <span className="block transform translate-y-[2px] drop-shadow-[0_1px_2px_rgba(255,255,255,0.5)]">
              FIRE UP
            </span>
          </motion.div>
        </motion.div>

        {/* LINE 4: YOUR FUTURE WITH EVERY */}
        <ScrollHighlightLine
          progress={scrollYProgress}
          range={[0.54, 0.74]}
          className="text-white"
        >
          YOUR FUTURE WITH EVERY
        </ScrollHighlightLine>

        {/* LINE 5: GULP OF PERFECT CAFFEINE */}
        <ScrollHighlightLine
          progress={scrollYProgress}
          range={[0.70, 0.90]}
          className="text-white mt-1 sm:mt-2"
        >
          GULP OF PERFECT CAFFEINE
        </ScrollHighlightLine>
      </motion.div>
    </section>
  );
};

