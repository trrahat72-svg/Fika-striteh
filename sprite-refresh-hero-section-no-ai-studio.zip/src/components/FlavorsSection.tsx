import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

const FLAVORS_BG_IMAGE = 'https://res.cloudinary.com/nhkvpmhr/image/upload/v1787996814/IMG-20260829-WA0019.jpg';
const SKY_CLOUD_MASK_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787815925/file_00000000d2848211a74f06c8f2a75677_vyxyww.png';
const FIRST_BASE_CAN = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753604/file_00000000689081fdba99b19e7dbc6094_hf8odj.png';
const TROPICAL_CAN = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787799318/file_00000000db2882098893b24b1616b047_uw6bka.png';
const STRAWBERRY_CAN = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787904550/file_0000000094d4821184283e00ba43d802_qa9fxr.png';

export const FlavorsSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  // Parallax scroll scrub linked to viewport progress
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  // 1. Background layer 3D depth parallax
  const bgY = useTransform(scrollYProgress, [0, 1], [-60, 60]);
  const bgScale = useTransform(scrollYProgress, [0, 0.5, 1], [1.06, 1.02, 1.06]);

  // 2. Desktop Individual Typography Cinematic Scroll Transforms
  // Word: "WE" (Top-Left entrance & lift)
  const weY = useTransform(scrollYProgress, [0.08, 0.45], [40, -18]);
  const weX = useTransform(scrollYProgress, [0.08, 0.45], [-20, 0]);
  const weOpacity = useTransform(scrollYProgress, [0.08, 0.28], [0.2, 1]);
  const weScale = useTransform(scrollYProgress, [0.08, 0.32], [0.88, 1]);

  // Word: "HAVE" (Top-Right entrance & lift)
  const haveY = useTransform(scrollYProgress, [0.12, 0.5], [50, -22]);
  const haveX = useTransform(scrollYProgress, [0.12, 0.5], [25, 0]);
  const haveOpacity = useTransform(scrollYProgress, [0.12, 0.34], [0.2, 1]);
  const haveScale = useTransform(scrollYProgress, [0.12, 0.38], [0.88, 1]);

  // Number: "03" (Left anchor dynamic rise & scale)
  const numY = useTransform(scrollYProgress, [0.18, 0.56], [65, -28]);
  const numX = useTransform(scrollYProgress, [0.18, 0.56], [-30, 0]);
  const numOpacity = useTransform(scrollYProgress, [0.16, 0.42], [0.2, 1]);
  const numScale = useTransform(scrollYProgress, [0.16, 0.46], [0.85, 1]);
  const numRotate = useTransform(scrollYProgress, [0.18, 0.56], [-4, 0]);

  // Word: "FLAVORS" (Right anchor sweeping reveal)
  const flavorsY = useTransform(scrollYProgress, [0.22, 0.62], [75, -32]);
  const flavorsX = useTransform(scrollYProgress, [0.22, 0.62], [35, 0]);
  const flavorsOpacity = useTransform(scrollYProgress, [0.2, 0.48], [0.2, 1]);
  const flavorsScale = useTransform(scrollYProgress, [0.2, 0.52], [0.86, 1]);

  // 3. Multi-layered Product Cans Parallax (Differential speeds for 3D depth)
  // Left Strawberry Can (Far background, faster float & tilt)
  const canLeftY = useTransform(scrollYProgress, [0, 1], [85, -85]);
  const canLeftRotate = useTransform(scrollYProgress, [0, 1], [-4, -14]);
  const canLeftScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.94, 1.02, 0.96]);

  // Right Tropical Can (Far background, opposite tilt & differential lift)
  const canRightY = useTransform(scrollYProgress, [0, 1], [95, -95]);
  const canRightRotate = useTransform(scrollYProgress, [0, 1], [4, 14]);
  const canRightScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.94, 1.02, 0.96]);

  // Center Hero Sprite Can (Foreground anchor, subtle commanding lift & crisp scale)
  const heroCanY = useTransform(scrollYProgress, [0, 1], [35, -35]);
  const heroCanScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.96, 1.03, 0.98]);

  // 4. Atmospheric Seam Cloud Mask Dynamic Scroll Shift & Parallax
  const cloudMaskY = useTransform(scrollYProgress, [0, 0.5, 1], [-30, 0, 35]);
  const cloudMaskScale = useTransform(scrollYProgress, [0, 0.5, 1], [1.04, 1.0, 0.98]);

  // 5. Mobile Scroll-Linked Transforms
  const mobileTopTextY = useTransform(scrollYProgress, [0.08, 0.42], [30, -10]);
  const mobileTopTextOpacity = useTransform(scrollYProgress, [0.06, 0.28], [0.2, 1]);
  const mobileTopTextScale = useTransform(scrollYProgress, [0.06, 0.3], [0.9, 1]);

  const mobileBottomTextY = useTransform(scrollYProgress, [0.15, 0.5], [40, -15]);
  const mobileBottomTextOpacity = useTransform(scrollYProgress, [0.12, 0.38], [0.2, 1]);
  const mobileBottomTextScale = useTransform(scrollYProgress, [0.12, 0.4], [0.9, 1]);

  const mobileLeftCanY = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const mobileLeftCanRotate = useTransform(scrollYProgress, [0, 1], [-8, -16]);

  const mobileRightCanY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const mobileRightCanRotate = useTransform(scrollYProgress, [0, 1], [8, 16]);

  const mobileHeroCanY = useTransform(scrollYProgress, [0, 1], [25, -25]);
  const mobileHeroCanScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.94, 1.02, 0.96]);

  return (
    <section
      ref={sectionRef}
      id="flavors"
      className="relative w-full bg-[#62b9f3] flex items-center justify-center select-none overflow-visible z-20"
    >
      {/* 
        0. ATMOSPHERIC SKY / CLOUD MASK (SEAM BETWEEN ABOUT & FLAVORS SECTION)
        Dynamically centered right at the seam (shifted 8px higher on mobile: -top-2 / md:top-0) and scrolls with dynamic parallax.
        Blurred with 25% (2.5px) soft edge filter and 89% opacity.
      */}
      <motion.div
        style={{
          y: cloudMaskY,
          scale: cloudMaskScale,
          filter: 'blur(2.5px)',
          opacity: 0.89,
        }}
        className="absolute -top-2 md:top-0 left-1/2 -translate-x-1/2 -translate-y-[48%] md:-translate-y-[50%] w-[210%] xs:w-[185%] sm:w-[160%] md:w-[142%] lg:w-[138%] max-w-[2200px] pointer-events-none z-50 overflow-visible flex items-center justify-center"
      >
        <img
          src={SKY_CLOUD_MASK_IMG}
          alt="Atmospheric Clouds Separation Mask"
          className="w-full h-auto max-h-none object-contain pointer-events-none select-none"
          crossOrigin="anonymous"
          loading="eager"
        />
      </motion.div>

      {/* Shared SVG Definitions for Text Linear Gradient & Drop Shadow Filter */}
      <svg className="absolute w-0 h-0 pointer-events-none" aria-hidden="true">
        <defs>
          <linearGradient id="flavorTextGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#EBFFC5" stopOpacity="1" />
            <stop offset="100%" stopColor="#FDFFF9" stopOpacity="1" />
          </linearGradient>
          <filter id="softTextShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="6" stdDeviation="5" floodColor="#000000" floodOpacity="0.2" />
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000000" floodOpacity="0.15" />
          </filter>
          <filter id="mobileTextShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="3" floodColor="#000000" floodOpacity="0.25" />
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.2" />
          </filter>
        </defs>
      </svg>

      {/* 
        ========================================================================
        A. DESKTOP & TABLET VIEWPORT (md:block)
        Matches exact reference design canvas: 1448 x 1086 px ratio with 3D Parallax
        ========================================================================
      */}
      <div className="hidden md:block relative w-full max-w-[1448px] aspect-[1448/1086] overflow-hidden">
        {/* Layer 1: Parallax Background Image */}
        <motion.div
          style={{ y: bgY, scale: bgScale }}
          className="absolute inset-[-6%] w-[112%] h-[112%] pointer-events-none z-0"
        >
          <img
            src={FLAVORS_BG_IMAGE}
            alt="Flavors Landscape Background"
            className="w-full h-full object-cover pointer-events-none"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Layer 2: Typography Layer with Individual Dynamic Scroll Animations */}
        <div className="absolute inset-0 z-10 pointer-events-none">
          {/* THE WORD "WE" */}
          <motion.div
            style={{
              left: `${(282.5 / 1448) * 100}%`,
              top: `${(121 / 1086) * 100}%`,
              width: `${(374.4 / 1448) * 100}%`,
              height: `${(309.2 / 1086) * 100}%`,
              y: weY,
              x: weX,
              opacity: weOpacity,
              scale: weScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 374.4 309.2" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="245"
                fontFamily="'Lilita One', sans-serif"
                fontSize="290"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="374.4"
                lengthAdjust="spacingAndGlyphs"
              >
                WE
              </text>
            </svg>
          </motion.div>

          {/* THE WORD "HAVE" */}
          <motion.div
            style={{
              left: `${(675 / 1448) * 100}%`,
              top: `${(143.4 / 1086) * 100}%`,
              width: `${(542.6 / 1448) * 100}%`,
              height: `${(269.4 / 1086) * 100}%`,
              y: haveY,
              x: haveX,
              opacity: haveOpacity,
              scale: haveScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 542.6 269.4" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="225"
                fontFamily="'Lilita One', sans-serif"
                fontSize="260"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="542.6"
                lengthAdjust="spacingAndGlyphs"
              >
                HAVE
              </text>
            </svg>
          </motion.div>

          {/* THE NUMBER "03" */}
          <motion.div
            style={{
              left: `${(117.9 / 1448) * 100}%`,
              top: `${(318.6 / 1086) * 100}%`,
              width: `${(419 / 1448) * 100}%`,
              height: `${(428.8 / 1086) * 100}%`,
              y: numY,
              x: numX,
              opacity: numOpacity,
              scale: numScale,
              rotate: numRotate,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 419 428.8" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="350"
                fontFamily="'Lilita One', sans-serif"
                fontSize="410"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="8"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="419"
                lengthAdjust="spacingAndGlyphs"
              >
                03
              </text>
            </svg>
          </motion.div>

          {/* THE WORD "FLAVORS" */}
          <motion.div
            style={{
              left: `${(549.9 / 1448) * 100}%`,
              top: `${(384.1 / 1086) * 100}%`,
              width: `${(853.8 / 1448) * 100}%`,
              height: `${(255.7 / 1086) * 100}%`,
              y: flavorsY,
              x: flavorsX,
              opacity: flavorsOpacity,
              scale: flavorsScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 853.8 255.7" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="215"
                fontFamily="'Lilita One', sans-serif"
                fontSize="250"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="853.8"
                lengthAdjust="spacingAndGlyphs"
              >
                FLAVORS
              </text>
            </svg>
          </motion.div>
        </div>

        {/* Layer 3: Product Cans Layer with Differential Parallax Depths */}
        {/* Strawberry Can (Left Background Layer) */}
        <motion.div
          style={{
            left: `${(-29.6 / 1448) * 100}%`,
            top: `${(543 / 1086) * 100}%`,
            width: `${(377.2 / 1448) * 100}%`,
            height: `${(251.4 / 1086) * 100}%`,
            y: canLeftY,
            rotate: canLeftRotate,
            scale: canLeftScale,
          }}
          className="absolute z-15 pointer-events-none flex items-center justify-center"
        >
          <img
            src={STRAWBERRY_CAN}
            alt="Strawberry Flavor Can"
            className="w-full h-full object-contain filter blur-[2.5px] opacity-95"
            crossOrigin="anonymous"
            loading="lazy"
          />
        </motion.div>

        {/* Tropical Can (Right Background Layer) */}
        <motion.div
          style={{
            left: `${(1123.4 / 1448) * 100}%`,
            top: `${(524.7 / 1086) * 100}%`,
            width: `${(432 / 1448) * 100}%`,
            height: `${(288 / 1086) * 100}%`,
            y: canRightY,
            rotate: canRightRotate,
            scale: canRightScale,
          }}
          className="absolute z-15 pointer-events-none flex items-center justify-center"
        >
          <img
            src={TROPICAL_CAN}
            alt="Tropical Orange Flavor Can"
            className="w-full h-full object-contain filter blur-[2.5px] opacity-95"
            crossOrigin="anonymous"
            loading="lazy"
          />
        </motion.div>

        {/* Center Hero Can (Foreground Layer) */}
        <motion.div
          style={{
            left: `${(252.2 / 1448) * 100}%`,
            top: `${(384.1 / 1086) * 100}%`,
            width: `${(1011.4 / 1448) * 100}%`,
            height: `${(674.2 / 1086) * 100}%`,
            y: heroCanY,
            scale: heroCanScale,
          }}
          className="absolute z-20 pointer-events-none flex items-center justify-center"
        >
          <img
            src={FIRST_BASE_CAN}
            alt="Original Sprite Lemon-Lime Can"
            className="w-full h-full object-contain filter drop-shadow-[0_16px_24px_rgba(0,0,0,0.4)] drop-shadow-[0_4px_8px_rgba(0,0,0,0.25)]"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>
      </div>

      {/* 
        ========================================================================
        B. MOBILE VIEWPORT (block md:hidden)
        100% Responsive, proportional layout with 3D scroll depth
        ========================================================================
      */}
      <div className="block md:hidden relative w-full min-h-[560px] xs:min-h-[600px] sm:min-h-[680px] overflow-hidden">
        {/* Parallax Background Image */}
        <motion.div
          style={{ y: bgY, scale: bgScale }}
          className="absolute inset-[-8%] w-[116%] h-[116%] pointer-events-none z-0"
        >
          <img
            src={FLAVORS_BG_IMAGE}
            alt="Flavors Landscape Background"
            className="w-full h-full object-cover object-center pointer-events-none"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Mobile Typography Layer with Dynamic Scroll Reveal */}
        <div className="relative z-10 w-full pt-12 xs:pt-14 sm:pt-20 px-4 flex flex-col items-center pointer-events-none">
          {/* Top Line: WE HAVE */}
          <motion.div
            style={{
              y: mobileTopTextY,
              opacity: mobileTopTextOpacity,
              scale: mobileTopTextScale,
            }}
            className="w-full max-w-[360px] flex items-center justify-center"
          >
            <svg viewBox="0 0 540 140" className="w-[85%] max-w-[320px] h-auto overflow-visible">
              <text
                x="50%"
                y="110"
                textAnchor="middle"
                fontFamily="'Lilita One', sans-serif"
                fontSize="120"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="5"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#mobileTextShadow)"
                letterSpacing="4"
              >
                WE HAVE
              </text>
            </svg>
          </motion.div>

          {/* Bottom Line: 03 FLAVORS */}
          <motion.div
            style={{
              y: mobileBottomTextY,
              opacity: mobileBottomTextOpacity,
              scale: mobileBottomTextScale,
            }}
            className="w-full max-w-[420px] flex items-center justify-center -mt-2 xs:-mt-1"
          >
            <svg viewBox="0 0 660 150" className="w-[95%] max-w-[380px] h-auto overflow-visible">
              <text
                x="50%"
                y="120"
                textAnchor="middle"
                fontFamily="'Lilita One', sans-serif"
                fontSize="130"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="5.5"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#mobileTextShadow)"
                letterSpacing="2"
              >
                03 FLAVORS
              </text>
            </svg>
          </motion.div>
        </div>

        {/* Mobile Product Cans Composition with Parallax Depth */}
        <div className="relative w-full h-[320px] xs:h-[360px] sm:h-[420px] mt-2 xs:mt-4 z-20 flex items-center justify-center pointer-events-none">
          {/* Strawberry Can (Floating Left Background Blur) */}
          <motion.div
            style={{
              y: mobileLeftCanY,
              rotate: mobileLeftCanRotate,
            }}
            className="absolute left-[-15%] xs:left-[-10%] sm:left-[-4%] bottom-[12%] xs:bottom-[15%] w-[42%] xs:w-[40%] max-w-[190px] aspect-[3/2] z-10"
          >
            <img
              src={STRAWBERRY_CAN}
              alt="Strawberry Flavor Can"
              className="w-full h-full object-contain filter blur-[2px] opacity-90"
              crossOrigin="anonymous"
              loading="lazy"
            />
          </motion.div>

          {/* Tropical Can (Floating Right Background Blur) */}
          <motion.div
            style={{
              y: mobileRightCanY,
              rotate: mobileRightCanRotate,
            }}
            className="absolute right-[-15%] xs:right-[-10%] sm:right-[-4%] bottom-[14%] xs:bottom-[16%] w-[44%] xs:w-[42%] max-w-[200px] aspect-[3/2] z-10"
          >
            <img
              src={TROPICAL_CAN}
              alt="Tropical Orange Flavor Can"
              className="w-full h-full object-contain filter blur-[2px] opacity-90"
              crossOrigin="anonymous"
              loading="lazy"
            />
          </motion.div>

          {/* Hero Sprite Lemon-Lime Can (Center Foreground) */}
          <motion.div
            style={{
              y: mobileHeroCanY,
              scale: mobileHeroCanScale,
            }}
            className="relative w-[85%] xs:w-[82%] sm:w-[75%] max-w-[380px] aspect-[3/2] z-20 flex items-center justify-center"
          >
            <img
              src={FIRST_BASE_CAN}
              alt="Original Sprite Lemon-Lime Can"
              className="w-full h-full object-contain filter drop-shadow-[0_14px_20px_rgba(0,0,0,0.38)] drop-shadow-[0_4px_8px_rgba(0,0,0,0.2)]"
              crossOrigin="anonymous"
              loading="eager"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};


