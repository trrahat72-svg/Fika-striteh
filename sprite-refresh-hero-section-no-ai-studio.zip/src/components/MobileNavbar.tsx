import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, Sparkles } from 'lucide-react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface MobileNavbarProps {
  revealTrigger?: number;
}

export const MobileNavbar: React.FC<MobileNavbarProps> = ({ revealTrigger = 0 }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'Discover' | 'Flavors' | 'Refresh' | 'Explore'>('Discover');

  const handleMobileNav = (tab: 'Discover' | 'Flavors' | 'Refresh' | 'Explore') => {
    setActiveTab(tab);
    spriteAudio.playButtonTap();
    setIsOpen(false);
    if (tab === 'Flavors') {
      setTimeout(() => {
        const el = document.getElementById('flavors');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 250);
    } else if (tab === 'Refresh' || tab === 'Explore') {
      setTimeout(() => {
        const aboutEl = document.getElementById('about');
        aboutEl?.scrollIntoView({ behavior: 'smooth' });
      }, 250);
    } else {
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 250);
    }
  };

  return (
    <>
      {/* Mobile Top Header */}
      <header className="fixed top-0 left-0 right-0 z-40 px-5 pt-4 pb-3 flex items-center justify-between w-full">
        {/* Sprite Logo with Elastic Drop */}
        <motion.div
          key={`mob-logo-${revealTrigger}`}
          initial={{ y: -30, opacity: 0, scale: 0.9 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.1, ease: [0.19, 1, 0.22, 1] }}
          className="relative"
        >
          <button
            onClick={() => {
              spriteAudio.playButtonTap();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="transition-transform active:scale-95 duration-200 block cursor-pointer"
          >
            <SpriteLogo className="h-9" />
          </button>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 0], scale: [0.5, 1.3, 0.8] }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="absolute -top-1 -right-2 text-[#FFE500]"
          >
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </motion.div>
        </motion.div>

        {/* Apple-style Frosted Glass Hamburger Toggle */}
        <motion.button
          key={`mob-menu-btn-${revealTrigger}`}
          initial={{ y: -30, opacity: 0, scale: 0.85 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.2, ease: [0.19, 1, 0.22, 1] }}
          onClick={() => {
            spriteAudio.playButtonTap();
            setIsOpen(!isOpen);
          }}
          aria-label={isOpen ? 'Close Menu' : 'Open Menu'}
          className="relative w-11 h-11 rounded-full flex items-center justify-center bg-white/[0.15] backdrop-blur-2xl border border-white/30 text-white shadow-[0_8px_20px_rgba(0,0,0,0.25),inset_0_1px_1px_rgba(255,255,255,0.4)] active:scale-90 transition-all duration-200 cursor-pointer"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="w-5 h-5 text-white" />
              </motion.div>
            ) : (
              <motion.div
                key="menu"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Menu className="w-5 h-5 text-white" />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </header>

      {/* Full-Screen Frosted Glass Mobile Menu Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-50 bg-[#071822]/90 backdrop-blur-3xl px-6 pt-24 pb-8 flex flex-col justify-between overflow-y-auto"
          >
            {/* Nav Links */}
            <div className="flex flex-col gap-3">
              {(['Discover', 'Flavors', 'Refresh', 'Explore'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => handleMobileNav(tab)}
                  className={`w-full py-3.5 px-6 rounded-2xl flex items-center justify-between text-left font-montserrat text-lg transition-all duration-200 cursor-pointer ${
                    activeTab === tab
                      ? 'bg-white/20 text-white font-bold border border-white/30 shadow-[0_4px_16px_rgba(0,0,0,0.2)]'
                      : 'text-white/80 hover:text-white hover:bg-white/10 font-medium'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    {tab}
                    {tab === 'Refresh' && (
                      <span className="w-2 h-2 rounded-full bg-[#65C435] shadow-[0_0_8px_#65C435]" />
                    )}
                  </span>
                  <ArrowRight className="w-4 h-4 opacity-60" />
                </button>
              ))}
            </div>

            {/* Shop Sprite Mobile CTA & Socials */}
            <div className="flex flex-col gap-5 pt-6 border-t border-white/15">
              <button
                onClick={() => {
                  spriteAudio.playCanPop();
                  setIsOpen(false);
                  setTimeout(() => {
                    const aboutEl = document.getElementById('about');
                    aboutEl?.scrollIntoView({ behavior: 'smooth' });
                  }, 250);
                }}
                className="w-full py-4 px-6 rounded-full bg-gradient-to-r from-[#0B571B] to-[#65C435] text-white font-montserrat font-semibold text-center flex items-center justify-center gap-2 shadow-[0_8px_24px_rgba(11,87,27,0.4)] active:scale-95 transition-all cursor-pointer"
              >
                <span>Shop Sprite</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Social links */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-white/70 font-montserrat text-sm font-medium">Follow Sprite</span>
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white text-xs font-semibold">
                    IG
                  </span>
                  <span className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white text-xs font-semibold">
                    TT
                  </span>
                  <span className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white text-xs font-semibold">
                    FB
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
