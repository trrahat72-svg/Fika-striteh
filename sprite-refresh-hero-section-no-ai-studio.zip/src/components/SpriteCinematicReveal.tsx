import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { spriteAudio } from '../utils/audio';

interface CinematicRevealProps {
  onComplete?: () => void;
  onTransitionStart?: () => void;
}

interface BubbleParticle {
  x: number;
  y: number;
  r: number;
  vy: number;
  vx: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export const SpriteCinematicReveal: React.FC<CinematicRevealProps> = ({
  onComplete,
  onTransitionStart,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [isDone, setIsDone] = useState<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let animationId: number;
    let startTime: number | null = null;
    const DURATION = 1600; // 1.6s: snappy, ultra-smooth fluid progression

    let w = window.innerWidth || 1440;
    let h = window.innerHeight || 1080;

    const updateSize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      // Cap DPR at 1.5 to guarantee solid 60/120 FPS on all high-res mobile and tablet screens
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    updateSize();
    window.addEventListener('resize', updateSize);

    const bubbles: BubbleParticle[] = [];
    let lastAudioTime = 0;
    let transitionTriggered = false;

    const render = (now: number) => {
      if (!startTime) startTime = now;
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / DURATION);

      // Smooth custom deceleration easing for loading progress
      const easedT = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      const currentPct = Math.min(100, Math.floor(easedT * 100));
      setProgress(currentPct);

      // Audio bubble fizz pop intervals
      if (now - lastAudioTime > 260 && t < 0.92) {
        spriteAudio.playFizzBubble();
        lastAudioTime = now;
      }

      const cx = w / 2;
      const cy = h / 2;
      const minDim = Math.min(w, h);

      // Compact, elegant fluid droplet: scaled down for lightweight performance
      const baseDropRadius = Math.max(34, minDim * 0.095) * (0.92 + easedT * 0.16);

      // 1. Solid Fresh Sprite Green Ambient Background
      const bgGradient = ctx.createRadialGradient(cx, cy * 0.92, minDim * 0.05, cx, cy, Math.max(w, h) * 0.8);
      bgGradient.addColorStop(0, '#009448');
      bgGradient.addColorStop(0.55, '#007A3B');
      bgGradient.addColorStop(1, '#005828');
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, w, h);

      // 2. Harmonic Fluid Droplet Geometry (18 nodes for maximum mobile smoothness)
      const numNodes = 18;
      const dropPoints: { x: number; y: number }[] = [];
      const timeSec = elapsed / 1000;

      for (let i = 0; i < numNodes; i++) {
        const angle = (i / numNodes) * Math.PI * 2;
        const wobble1 = Math.sin(angle * 3 + timeSec * 5) * (baseDropRadius * 0.05);
        const wobble2 = Math.cos(angle * 4 - timeSec * 6) * (baseDropRadius * 0.03);
        const r = baseDropRadius + wobble1 + wobble2;

        dropPoints.push({
          x: cx + Math.cos(angle) * r,
          y: cy + Math.sin(angle) * r,
        });
      }

      // Outer Citrus Caustic Halo
      ctx.save();
      const haloGrad = ctx.createRadialGradient(cx, cy, baseDropRadius * 0.7, cx, cy, baseDropRadius * 1.4);
      haloGrad.addColorStop(0, 'rgba(255, 229, 0, 0.35)');
      haloGrad.addColorStop(0.5, 'rgba(167, 228, 51, 0.16)');
      haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = haloGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, baseDropRadius * 1.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Fluid Droplet Body
      ctx.save();
      ctx.beginPath();
      const firstMid = {
        x: (dropPoints[0].x + dropPoints[numNodes - 1].x) / 2,
        y: (dropPoints[0].y + dropPoints[numNodes - 1].y) / 2,
      };
      ctx.moveTo(firstMid.x, firstMid.y);

      for (let i = 0; i < numNodes; i++) {
        const nextIdx = (i + 1) % numNodes;
        const midX = (dropPoints[i].x + dropPoints[nextIdx].x) / 2;
        const midY = (dropPoints[i].y + dropPoints[nextIdx].y) / 2;
        ctx.quadraticCurveTo(dropPoints[i].x, dropPoints[i].y, midX, midY);
      }
      ctx.closePath();

      // Liquid refractive gradient (zero runtime shadowBlur lag)
      const liquidGrad = ctx.createRadialGradient(
        cx - baseDropRadius * 0.35,
        cy - baseDropRadius * 0.35,
        baseDropRadius * 0.1,
        cx,
        cy,
        baseDropRadius * 1.15
      );
      liquidGrad.addColorStop(0, '#FFFFFF');
      liquidGrad.addColorStop(0.2, '#FFE500'); // Lemon-lime yellow
      liquidGrad.addColorStop(0.55, '#85D829'); // Crisp lime
      liquidGrad.addColorStop(0.85, '#009B4D');
      liquidGrad.addColorStop(1, '#006E34');
      ctx.fillStyle = liquidGrad;
      ctx.fill();

      // Glass rim stroke
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.lineWidth = Math.max(1.5, minDim * 0.0035);
      ctx.stroke();
      ctx.restore();

      // Specular Light Curved Reflection
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(
        cx - baseDropRadius * 0.32,
        cy - baseDropRadius * 0.35,
        baseDropRadius * 0.35,
        baseDropRadius * 0.16,
        -Math.PI / 4,
        0,
        Math.PI * 2
      );
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.fill();
      ctx.restore();

      // Sparkling Micro-Bubbles (Lightweight pool of max 18 bubbles)
      if (Math.random() < 0.5 && bubbles.length < 18) {
        bubbles.push({
          x: cx + (Math.random() - 0.5) * (baseDropRadius * 0.9),
          y: cy + baseDropRadius * 0.5,
          r: Math.random() * 2 + 1,
          vy: Math.random() * 1.8 + 1.0,
          vx: (Math.random() - 0.5) * 0.5,
          alpha: Math.random() * 0.6 + 0.3,
          life: 0,
          maxLife: Math.random() * 35 + 20,
        });
      }

      ctx.save();
      for (let i = bubbles.length - 1; i >= 0; i--) {
        const b = bubbles[i];
        b.y -= b.vy;
        b.x += b.vx;
        b.life++;

        const bAlpha = (1 - b.life / b.maxLife) * b.alpha;
        if (b.life >= b.maxLife) {
          bubbles.splice(i, 1);
          continue;
        }

        ctx.fillStyle = `rgba(255, 255, 255, ${bAlpha})`;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Trigger start of transition right as progress completes
      if (t >= 0.98 && !transitionTriggered) {
        transitionTriggered = true;
        spriteAudio.playRefreshBurst();
        if (onTransitionStart) onTransitionStart();
        setIsTransitioning(true);
      }

      if (t < 1) {
        animationId = requestAnimationFrame(render);
      } else {
        // Fast, graceful handoff
        setTimeout(() => {
          setIsDone(true);
          if (onComplete) onComplete();
        }, 900);
      }
    };

    animationId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', updateSize);
    };
  }, [onComplete, onTransitionStart]);

  if (isDone) return null;

  return (
    <div
      ref={containerRef}
      id="sprite-global-website-loader"
      className="fixed inset-0 z-50 pointer-events-none select-none flex items-center justify-center overflow-hidden w-screen h-screen"
      style={{ transform: 'translateZ(0)' }}
    >
      {/* 1. SOLID FRESH SPRITE GREEN BACKGROUND VEIL (Hardware-Accelerated Fade & Zoom) */}
      <motion.div
        className="absolute inset-0 w-full h-full will-change-transform"
        initial={{ opacity: 1, scale: 1 }}
        animate={{
          opacity: isTransitioning ? 0 : 1,
          scale: isTransitioning ? 1.08 : 1,
        }}
        transition={{
          duration: 0.85,
          ease: [0.19, 1, 0.22, 1],
        }}
      >
        <canvas ref={canvasRef} className="w-full h-full block" />
      </motion.div>

      {/* 2. EXPANDING LIQUID APERTURE WAVE */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0.9 }}
            animate={{ scale: 16, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.85,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="absolute z-30 w-28 h-28 rounded-full border-4 border-white/80 pointer-events-none shadow-[0_0_50px_rgba(255,229,0,0.8)]"
            style={{
              background: 'radial-gradient(circle, rgba(255,255,255,0.4) 0%, rgba(255,229,0,0.2) 40%, rgba(0,148,72,0) 75%)',
            }}
          />
        )}
      </AnimatePresence>

      {/* 3. MINIMALIST COMPACT PROGRESS COUNTER */}
      <motion.div
        className="relative z-20 flex flex-col items-center justify-center pointer-events-none"
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{
          scale: isTransitioning ? 1.2 : 1,
          opacity: isTransitioning ? 0 : 1,
        }}
        transition={{
          duration: isTransitioning ? 0.45 : 0.4,
          ease: [0.19, 1, 0.22, 1],
        }}
      >
        <div className="flex items-baseline font-montserrat font-black text-white select-none drop-shadow-[0_2px_8px_rgba(0,0,0,0.35)]">
          <span
            className="tracking-tighter leading-none"
            style={{
              fontSize: 'clamp(24px, 6vw, 38px)',
            }}
          >
            {progress}
          </span>
          <span
            className="text-[#FFE500] font-bold font-mono ml-0.5"
            style={{
              fontSize: 'clamp(14px, 3.2vw, 20px)',
            }}
          >
            %
          </span>
        </div>
      </motion.div>
    </div>
  );
};
