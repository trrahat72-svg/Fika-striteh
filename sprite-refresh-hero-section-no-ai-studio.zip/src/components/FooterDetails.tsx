import React from 'react';
import { motion } from 'motion/react';

interface FooterDetailsProps {
  revealTrigger?: number;
}

export const FooterDetails: React.FC<FooterDetailsProps> = ({ revealTrigger = 0 }) => {
  const lines = ['Crisp citrus.', 'Cold refresh.', 'Nothing ordinary.'];

  return (
    <>
      {/* Bottom Right 3-line Text Content (Canva Spec 5: X: 1259.8px, Y: 945px, W: 153.5px, H: 65.6px) */}
      <div
        className="absolute z-20 font-montserrat text-left pointer-events-none"
        style={{
          left: '1259.8px',
          top: '945px',
          width: '153.5px',
          height: '65.6px',
        }}
      >
        <div className="flex flex-col gap-0.5">
          {lines.map((line, idx) => (
            <motion.p
              key={`${line}-${revealTrigger}`}
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{
                duration: 0.8,
                delay: 0.9 + idx * 0.12,
                ease: [0.19, 1, 0.22, 1],
              }}
              className="text-white/90 text-[13px] leading-[1.35] font-medium tracking-wide"
            >
              {line}
            </motion.p>
          ))}
        </div>
      </div>

      {/* Right Border Vertical Watermark */}
      <motion.div
        key={`watermark-${revealTrigger}`}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{
          duration: 1.0,
          delay: 1.1,
          ease: [0.19, 1, 0.22, 1],
        }}
        className="absolute right-4 top-[740px] z-20 pointer-events-none rotate-90 origin-right"
        style={{
          transformOrigin: 'bottom right',
        }}
      >
        <span className="font-montserrat text-[9px] uppercase tracking-[0.25em] text-white/35 font-light">
          Borcelle Refresh
        </span>
      </motion.div>
    </>
  );
};
