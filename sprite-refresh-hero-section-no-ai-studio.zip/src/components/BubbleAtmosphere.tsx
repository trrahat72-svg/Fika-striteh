import React from 'react';
import { motion } from 'motion/react';

// Atmospheric Sprite effervescent carbonation bokeh bubbles covering empty spaces
export const BubbleAtmosphere: React.FC = () => {
  const bubbles = [
    // === LEFT FLANK (Empty area above & around social links) ===
    { id: 1, x: 50, y: 430, size: 120, blur: 16, opacity: 0.28, delay: 0.2, duration: 7.5, floatY: -45, floatX: 12 },
    { id: 2, x: 140, y: 580, size: 145, blur: 20, opacity: 0.22, delay: 1.5, duration: 8.5, floatY: -55, floatX: -14 },
    { id: 3, x: 230, y: 470, size: 85, blur: 9, opacity: 0.32, delay: 0.8, duration: 6.8, floatY: -40, floatX: 10 },
    { id: 4, x: 75, y: 710, size: 100, blur: 12, opacity: 0.26, delay: 2.1, duration: 8.0, floatY: -50, floatX: 8 },
    { id: 5, x: 190, y: 690, size: 68, blur: 6, opacity: 0.35, delay: 0.4, duration: 6.2, floatY: -35, floatX: -10 },
    { id: 6, x: 30, y: 570, size: 80, blur: 10, opacity: 0.25, delay: 1.8, duration: 7.0, floatY: -40, floatX: 9 },
    { id: 7, x: 110, y: 830, size: 45, blur: 4, opacity: 0.40, delay: 1.1, duration: 5.8, floatY: -30, floatX: 6 },
    { id: 8, x: 170, y: 870, size: 32, blur: 3, opacity: 0.42, delay: 2.6, duration: 5.2, floatY: -25, floatX: -5 },
    { id: 9, x: 90, y: 260, size: 75, blur: 11, opacity: 0.22, delay: 3.0, duration: 9.0, floatY: -35, floatX: 8 },

    // === RIGHT FLANK (Empty area above & around footer text) ===
    { id: 10, x: 1260, y: 410, size: 150, blur: 22, opacity: 0.24, delay: 0.6, duration: 8.8, floatY: -50, floatX: -12 },
    { id: 11, x: 1330, y: 570, size: 115, blur: 15, opacity: 0.28, delay: 1.9, duration: 7.6, floatY: -45, floatX: 10 },
    { id: 12, x: 1180, y: 660, size: 90, blur: 10, opacity: 0.30, delay: 0.9, duration: 6.5, floatY: -38, floatX: -8 },
    { id: 13, x: 1280, y: 770, size: 110, blur: 14, opacity: 0.26, delay: 2.3, duration: 8.2, floatY: -45, floatX: 11 },
    { id: 14, x: 1370, y: 710, size: 60, blur: 6, opacity: 0.38, delay: 1.4, duration: 6.0, floatY: -32, floatX: -6 },
    { id: 15, x: 1210, y: 860, size: 48, blur: 4, opacity: 0.42, delay: 0.7, duration: 5.5, floatY: -28, floatX: 7 },
    { id: 16, x: 1310, y: 260, size: 85, blur: 13, opacity: 0.20, delay: 2.8, duration: 9.2, floatY: -36, floatX: -9 },

    // === SUBTLE CENTER-LOWER DEPTH PARTICLES ===
    { id: 17, x: 420, y: 780, size: 70, blur: 12, opacity: 0.16, delay: 1.7, duration: 7.2, floatY: -30, floatX: 6 },
    { id: 18, x: 980, y: 780, size: 75, blur: 13, opacity: 0.18, delay: 2.2, duration: 7.5, floatY: -32, floatX: -7 },
  ];

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none z-5 overflow-hidden">
      {bubbles.map((b) => (
        <motion.div
          key={b.id}
          initial={{ y: 0, x: 0, opacity: b.opacity * 0.75 }}
          animate={{
            y: [0, b.floatY, 0],
            x: [0, b.floatX, 0],
            opacity: [b.opacity * 0.75, b.opacity * 1.15, b.opacity * 0.75],
            scale: [1, 1.04, 1],
          }}
          transition={{
            duration: b.duration,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: b.delay,
          }}
          className="absolute rounded-full select-none"
          style={{
            left: `${b.x}px`,
            top: `${b.y}px`,
            width: `${b.size}px`,
            height: `${b.size}px`,
            filter: `blur(${b.blur}px)`,
            background:
              'radial-gradient(circle at 32% 30%, rgba(255, 255, 255, 0.95) 0%, rgba(220, 255, 210, 0.65) 25%, rgba(135, 235, 125, 0.35) 55%, rgba(101, 196, 53, 0.12) 80%, transparent 100%)',
            boxShadow:
              'inset 0 2px 4px rgba(255, 255, 255, 0.8), inset 0 -2px 4px rgba(11, 87, 27, 0.3), 0 0 20px rgba(101, 196, 53, 0.28)',
            border: '1px solid rgba(255, 255, 255, 0.25)',
          }}
        />
      ))}
    </div>
  );
};
