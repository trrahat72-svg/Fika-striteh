import React from 'react';

export const SpriteLogo: React.FC<{ className?: string }> = ({ className = 'h-10' }) => {
  return (
    <div className={`flex items-center select-none ${className}`}>
      {/* Official Sprite Wordmark in crisp vector */}
      <svg
        viewBox="0 0 160 60"
        className="h-full w-auto fill-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.3)]"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g transform="skewX(-10)">
          {/* Stylized custom Sprite wordmark matching brand visual */}
          <text
            x="5"
            y="45"
            fontFamily="'Lilita One', 'Montserrat', sans-serif"
            fontWeight="900"
            fontSize="46"
            letterSpacing="-1.5"
            fill="#FFFFFF"
            fontStyle="italic"
          >
            Sprite
            <tspan fill="#65C435" fontSize="52">.</tspan>
          </text>
          {/* Subtle lime-lemon dot over 'i' spark */}
          <circle cx="94" cy="14" r="5.5" fill="#FFE500" />
          <circle cx="94" cy="14" r="3" fill="#65C435" />
        </g>
      </svg>
    </div>
  );
};
