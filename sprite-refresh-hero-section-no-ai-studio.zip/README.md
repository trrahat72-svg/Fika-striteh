# Sprite Refresh Hero Section

A high-fidelity Sprite “Refresh Your World” hero and About experience built with React, Vite, Tailwind CSS, and Motion.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```
